
# upb util library

The libraries in this directory contain useful functionality that is layered
on top of the main upb APIs.  In other words, the APIs in this directory have
no special access to upb internals; you could easily implement the same things
yourself.
